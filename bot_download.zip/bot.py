import discord
from discord.ext import commands
import os
import re
import datetime
from openai import AsyncOpenAI

DISCORD_BOT_TOKEN = os.environ["DISCORD_BOT_TOKEN"]
_owner_raw = os.environ.get("DISCORD_OWNER_ID", "").strip()
DISCORD_OWNER_ID: int | None = int(_owner_raw) if _owner_raw.isdigit() else None
DISCORD_OWNER_NAME: str | None = _owner_raw.lower() if not _owner_raw.isdigit() else None

AI_BASE_URL = os.environ["AI_INTEGRATIONS_OPENAI_BASE_URL"]
AI_API_KEY = os.environ["AI_INTEGRATIONS_OPENAI_API_KEY"]

openai_client = AsyncOpenAI(
    base_url=AI_BASE_URL,
    api_key=AI_API_KEY,
)

ALLOWED_CHANNELS = {"bot-chat", "👑emperor-ship-❤️‍🔥"}

URL_PATTERN = re.compile(
    r"(https?://[^\s]+|www\.[^\s]+|[^\s]+\.(com|net|org|io|gg|xyz|me|co|tv|ru|info|biz|app|dev)[^\s]*)",
    re.IGNORECASE
)

ABUSIVE_WORDS = [
    "fuck", "shit", "bitch", "asshole", "bastard", "cunt", "dick",
    "slut", "whore", "nigger", "nigga", "faggot", "retard",
    "kys", "kill yourself"
]

FORBIDDEN_TOPIC_PATTERNS = [
    r"\bhow\b.{0,30}\b(host|make|create|build|run|setup|set up|deploy)\b.{0,30}\bbot\b",
    r"\bbot\b.{0,30}\b(host|make|create|build|run|setup|set up|deploy)\b",
    r"\b(hosting|making|creating|building)\b.{0,20}\bbot\b",
    r"\bwhere.{0,20}host.{0,20}bot\b",
    r"\bhow.{0,20}bot.{0,20}work\b",
    r"\bbot\b.{0,20}\b(token|tutorial|source\s*code|github|script|python|discord\.py)\b",
    r"\bhow.{0,20}(get|steal|copy).{0,20}bot\b",
]

member_warnings: dict[int, int] = {}
spam_tracker: dict[int, list] = {}

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)


def is_owner_user(user: discord.User | discord.Member) -> bool:
    if DISCORD_OWNER_ID is not None:
        return user.id == DISCORD_OWNER_ID
    if DISCORD_OWNER_NAME is not None:
        return user.name.lower() == DISCORD_OWNER_NAME or str(user).lower() == DISCORD_OWNER_NAME
    return False


def is_owner():
    async def predicate(ctx: commands.Context):
        if not is_owner_user(ctx.author):
            await ctx.send("❌ Only the server owner can use this command.")
            return False
        return True
    return commands.check(predicate)


def in_allowed_channel():
    async def predicate(ctx: commands.Context):
        if ctx.channel.name not in ALLOWED_CHANNELS:
            names = " or ".join(f"`#{n}`" for n in ALLOWED_CHANNELS)
            await ctx.send(f"❌ This command can only be used in {names}.", delete_after=8)
            return False
        return True
    return commands.check(predicate)


def contains_abuse(text: str) -> bool:
    text_lower = text.lower()
    for word in ABUSIVE_WORDS:
        pattern = r'\b' + re.escape(word) + r'\b'
        if re.search(pattern, text_lower):
            return True
    return False


def contains_link(text: str) -> bool:
    return bool(URL_PATTERN.search(text))


def contains_forbidden_topic(text: str) -> bool:
    text_lower = text.lower()
    for pattern in FORBIDDEN_TOPIC_PATTERNS:
        if re.search(pattern, text_lower, re.IGNORECASE | re.DOTALL):
            return True
    return False


async def get_ai_response(question: str, context: str = "") -> str:
    messages = [
        {
            "role": "system",
            "content": (
                "You are a helpful, polite, and friendly Discord bot assistant. "
                "Always respond in a kind, respectful, and encouraging tone. "
                "Keep answers concise and easy to understand. "
                "Never use rude, offensive, or inappropriate language. "
                "If a question is unclear, ask for clarification politely."
            )
        }
    ]
    if context:
        messages.append({"role": "system", "content": context})
    messages.append({"role": "user", "content": question})

    try:
        response = await openai_client.chat.completions.create(
            model="gpt-5.1",
            max_completion_tokens=512,
            messages=messages
        )
        return response.choices[0].message.content or "I'm not sure how to answer that. Could you rephrase?"
    except Exception as e:
        print(f"AI error: {e}")
        return "Sorry, I'm having trouble thinking right now. Please try again in a moment!"


@bot.event
async def on_ready():
    owner_display = DISCORD_OWNER_ID if DISCORD_OWNER_ID else DISCORD_OWNER_NAME
    print(f"✅ Bot is online as {bot.user} (ID: {bot.user.id})")
    print(f"👑 Owner configured as: {owner_display}")
    print(f"📢 Allowed channels: {ALLOWED_CHANNELS}")
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching,
        name="the server | !ask"
    ))


async def apply_warning(message: discord.Message, reason_title: str, reason_desc: str) -> None:
    warnings = member_warnings.get(message.author.id, 0) + 1
    member_warnings[message.author.id] = warnings

    if warnings >= 3:
        try:
            until = discord.utils.utcnow() + datetime.timedelta(minutes=10)
            await message.author.timeout(until, reason=reason_title)
            embed = discord.Embed(
                title="🔇 Member Timed Out",
                description=(
                    f"{message.author.mention} has been timed out for **10 minutes**.\n"
                    f"Reason: {reason_title} ({warnings} warnings)."
                ),
                color=discord.Color.red()
            )
            await message.channel.send(embed=embed, delete_after=15)
            member_warnings[message.author.id] = 0
        except discord.Forbidden:
            pass
    else:
        embed = discord.Embed(
            title=f"⚠️ {reason_title}",
            description=(
                f"{message.author.mention}, {reason_desc}\n"
                f"This is warning **{warnings}/3**. After 3 warnings you will be timed out."
            ),
            color=discord.Color.orange()
        )
        embed.set_footer(text="Please follow the server rules.")
        await message.channel.send(embed=embed, delete_after=10)


@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return

    owner = is_owner_user(message.author)
    ch_name = message.channel.name
    in_allowed = ch_name in ALLOWED_CHANNELS
    in_bot_chat = ch_name == "bot-chat"



    if not owner and in_allowed:
        # 1. Forbidden topic check (how to host/make a bot) → instant timeout
        if contains_forbidden_topic(message.content):
            try:
                await message.delete()
            except discord.Forbidden:
                pass
            try:
                until = discord.utils.utcnow() + datetime.timedelta(minutes=15)
                await message.author.timeout(until, reason="Asked about bot hosting/creation")
                embed = discord.Embed(
                    title="🔇 Timed Out — Forbidden Topic",
                    description=(
                        f"{message.author.mention}, asking about how to host or make bots "
                        f"is not allowed here.\n"
                        f"You have been timed out for **15 minutes**."
                    ),
                    color=discord.Color.dark_red()
                )
                await message.channel.send(embed=embed, delete_after=20)
            except discord.Forbidden:
                pass
            return

        # 2. Link check
        if contains_link(message.content):
            try:
                await message.delete()
            except discord.Forbidden:
                pass
            await apply_warning(message, "Link Removed", "links are not allowed in this server.")
            return

        # 3. Abuse check
        if contains_abuse(message.content):
            try:
                await message.delete()
            except discord.Forbidden:
                pass
            await apply_warning(message, "Language Warning", "please keep the language respectful.")
            return

    # 4. Process commands first
    if message.content.startswith("!"):
        if in_allowed or owner:
            await bot.process_commands(message)
        return

    # 5. Auto-reply with AI in #bot-chat for every normal message (everyone including owner)
    if in_bot_chat:
        async with message.channel.typing():
            answer = await get_ai_response(
                message.content,
                context=(
                    "You are a friendly chat companion in a Discord server's #bot-chat channel. "
                    "Reply naturally and conversationally to what the user said. "
                    "Keep replies short (1-3 sentences). Be warm, fun, and polite. "
                    "Do NOT help with anything related to making, hosting, or coding Discord bots."
                )
            )
        await message.reply(answer)
        return

    # 6. In #👑emperor-ship-❤️‍🔥, reply with AI only when the bot is pinged/mentioned
    in_emperor = ch_name == "👑emperor-ship-❤️‍🔥"
    bot_mentioned = bot.user in message.mentions
    if in_emperor and bot_mentioned:
        # Strip the bot mention from the message to get the actual question
        question = message.content.replace(f"<@{bot.user.id}>", "").replace(f"<@!{bot.user.id}>", "").strip()
        if not question:
            question = "Hello! How can I help?"
        async with message.channel.typing():
            answer = await get_ai_response(
                question,
                context=(
                    "You are a helpful and polite assistant in a Discord server's VIP channel called emperor-ship. "
                    "Reply respectfully and helpfully. Keep replies concise. "
                    "Do NOT help with anything related to making, hosting, or coding Discord bots."
                )
            )
        await message.reply(answer)
        return

    if in_allowed or owner:
        await bot.process_commands(message)


@bot.command(name="ask")
@in_allowed_channel()
async def ask(ctx: commands.Context, *, question: str = None):
    if not question:
        await ctx.send("Please ask a question! Example: `!ask What is Python?`")
        return

    async with ctx.typing():
        answer = await get_ai_response(question)

    embed = discord.Embed(
        title="🤖 Answer",
        description=answer,
        color=discord.Color.blurple()
    )
    embed.set_footer(text=f"Asked by {ctx.author.display_name}")
    await ctx.reply(embed=embed)


@bot.command(name="roast")
@in_allowed_channel()
async def roast(ctx: commands.Context, member: discord.Member = None):
    target = member or ctx.author
    async with ctx.typing():
        answer = await get_ai_response(
            f"Give a funny, light-hearted roast for a Discord user named '{target.display_name}'. Keep it playful, not mean.",
            context="You are a witty comedian. Your roasts are always funny and never truly offensive."
        )
    embed = discord.Embed(
        title=f"🔥 Roasting {target.display_name}",
        description=answer,
        color=discord.Color.orange()
    )
    embed.set_footer(text=f"Requested by {ctx.author.display_name}")
    await ctx.send(embed=embed)


@bot.command(name="joke")
@in_allowed_channel()
async def joke(ctx: commands.Context):
    async with ctx.typing():
        answer = await get_ai_response(
            "Tell me one short, clean, and funny joke.",
            context="You are a comedian. Only tell safe-for-work jokes."
        )
    embed = discord.Embed(
        title="😂 Here's a Joke!",
        description=answer,
        color=discord.Color.yellow()
    )
    await ctx.send(embed=embed)


@bot.command(name="advice")
@in_allowed_channel()
async def advice(ctx: commands.Context, *, topic: str = None):
    prompt = f"Give me one piece of helpful life advice about: {topic}" if topic else "Give me one random piece of helpful life advice."
    async with ctx.typing():
        answer = await get_ai_response(prompt)
    embed = discord.Embed(
        title="💡 Advice",
        description=answer,
        color=discord.Color.green()
    )
    embed.set_footer(text=f"Requested by {ctx.author.display_name}")
    await ctx.send(embed=embed)


@bot.command(name="userinfo")
@in_allowed_channel()
async def userinfo(ctx: commands.Context, member: discord.Member = None):
    member = member or ctx.author
    embed = discord.Embed(
        title=f"👤 {member.display_name}'s Info",
        color=member.color if member.color != discord.Color.default() else discord.Color.blurple()
    )
    embed.set_thumbnail(url=member.display_avatar.url)
    embed.add_field(name="Username", value=str(member), inline=True)
    embed.add_field(name="ID", value=member.id, inline=True)
    embed.add_field(name="Joined Server", value=discord.utils.format_dt(member.joined_at, style="R") if member.joined_at else "Unknown", inline=True)
    embed.add_field(name="Account Created", value=discord.utils.format_dt(member.created_at, style="R"), inline=True)
    roles = [r.mention for r in member.roles if r.name != "@everyone"]
    embed.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles) if roles else "None", inline=False)
    embed.add_field(name="Warnings", value=str(member_warnings.get(member.id, 0)), inline=True)
    await ctx.send(embed=embed)


@bot.command(name="serverinfo")
@in_allowed_channel()
async def serverinfo(ctx: commands.Context):
    guild = ctx.guild
    embed = discord.Embed(
        title=f"🏰 {guild.name}",
        color=discord.Color.blurple()
    )
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    embed.add_field(name="Owner", value=guild.owner.mention if guild.owner else "Unknown", inline=True)
    embed.add_field(name="Members", value=guild.member_count, inline=True)
    embed.add_field(name="Channels", value=len(guild.channels), inline=True)
    embed.add_field(name="Roles", value=len(guild.roles), inline=True)
    embed.add_field(name="Created", value=discord.utils.format_dt(guild.created_at, style="R"), inline=True)
    embed.add_field(name="Boost Level", value=f"Level {guild.premium_tier}", inline=True)
    await ctx.send(embed=embed)


@bot.command(name="poll")
@in_allowed_channel()
async def poll(ctx: commands.Context, *, question: str = None):
    if not question:
        await ctx.send("Usage: `!poll <your question>`")
        return
    embed = discord.Embed(
        title="📊 Poll",
        description=question,
        color=discord.Color.blurple()
    )
    embed.set_footer(text=f"Poll by {ctx.author.display_name}")
    poll_msg = await ctx.send(embed=embed)
    await poll_msg.add_reaction("👍")
    await poll_msg.add_reaction("👎")
    await poll_msg.add_reaction("🤷")
    try:
        await ctx.message.delete()
    except discord.Forbidden:
        pass


@bot.command(name="say")
@is_owner()
async def say(ctx: commands.Context, *, text: str = None):
    if not text:
        await ctx.send("Usage: `!say <message>`")
        return
    try:
        await ctx.message.delete()
    except discord.Forbidden:
        pass
    await ctx.send(text)


@bot.command(name="announce")
@is_owner()
async def announce(ctx: commands.Context, *, text: str = None):
    if not text:
        await ctx.send("Usage: `!announce <message>`")
        return
    try:
        await ctx.message.delete()
    except discord.Forbidden:
        pass
    embed = discord.Embed(
        title="📢 Announcement",
        description=text,
        color=discord.Color.gold()
    )
    embed.set_footer(text=f"From {ctx.author.display_name}")
    await ctx.send(embed=embed)


@bot.command(name="purge")
@is_owner()
async def purge(ctx: commands.Context, amount: int = None):
    if amount is None or amount < 1:
        await ctx.send("Usage: `!purge <number>` (deletes that many messages)", delete_after=5)
        return
    if amount > 100:
        await ctx.send("❌ Max 100 messages at once.", delete_after=5)
        return
    deleted = await ctx.channel.purge(limit=amount + 1)
    await ctx.send(f"🗑️ Deleted {len(deleted) - 1} messages.", delete_after=5)


@bot.command(name="timeout")
@is_owner()
async def timeout_member(ctx: commands.Context, member: discord.Member = None, minutes: int = 5, *, reason: str = "No reason provided"):
    if not member:
        await ctx.send("Usage: `!timeout @member <minutes> [reason]`")
        return
    if is_owner_user(member):
        await ctx.send("❌ You cannot timeout the owner.")
        return
    if member.bot:
        await ctx.send("❌ You cannot timeout a bot.")
        return
    if minutes < 1 or minutes > 40320:
        await ctx.send("❌ Duration must be between 1 and 40320 minutes.")
        return
    try:
        until = discord.utils.utcnow() + datetime.timedelta(minutes=minutes)
        await member.timeout(until, reason=reason)
        embed = discord.Embed(
            title="🔇 Member Timed Out",
            description=f"{member.mention} has been timed out.",
            color=discord.Color.red()
        )
        embed.add_field(name="Duration", value=f"{minutes} minute(s)", inline=True)
        embed.add_field(name="Reason", value=reason, inline=True)
        embed.set_footer(text=f"Action by {ctx.author.display_name}")
        await ctx.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ I don't have permission. Make sure my role is above theirs.")


@bot.command(name="untimeout")
@is_owner()
async def untimeout_member(ctx: commands.Context, member: discord.Member = None):
    if not member:
        await ctx.send("Usage: `!untimeout @member`")
        return
    try:
        await member.timeout(None)
        embed = discord.Embed(
            title="✅ Timeout Removed",
            description=f"{member.mention}'s timeout has been removed.",
            color=discord.Color.green()
        )
        embed.set_footer(text=f"Action by {ctx.author.display_name}")
        await ctx.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ I don't have permission.")


@bot.command(name="ban")
@is_owner()
async def ban_member(ctx: commands.Context, member: discord.Member = None, *, reason: str = "No reason provided"):
    if not member:
        await ctx.send("Usage: `!ban @member [reason]`")
        return
    if is_owner_user(member):
        await ctx.send("❌ You cannot ban the owner.")
        return
    try:
        await member.ban(reason=reason, delete_message_days=0)
        embed = discord.Embed(
            title="🔨 Member Banned",
            description=f"{member.mention} has been banned.",
            color=discord.Color.dark_red()
        )
        embed.add_field(name="Reason", value=reason)
        embed.set_footer(text=f"Action by {ctx.author.display_name}")
        await ctx.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ I don't have permission to ban that member.")


@bot.command(name="unban")
@is_owner()
async def unban_member(ctx: commands.Context, *, user_id: str = None):
    if not user_id:
        await ctx.send("Usage: `!unban <user_id>`")
        return
    if not user_id.isdigit():
        await ctx.send("❌ Please provide a valid numeric user ID.")
        return
    try:
        user = await bot.fetch_user(int(user_id))
        await ctx.guild.unban(user)
        embed = discord.Embed(
            title="✅ Member Unbanned",
            description=f"{user} has been unbanned.",
            color=discord.Color.green()
        )
        embed.set_footer(text=f"Action by {ctx.author.display_name}")
        await ctx.send(embed=embed)
    except discord.NotFound:
        await ctx.send("❌ User not found or not banned.")
    except discord.Forbidden:
        await ctx.send("❌ I don't have permission to unban members.")


@bot.command(name="kick")
@is_owner()
async def kick_member(ctx: commands.Context, member: discord.Member = None, *, reason: str = "No reason provided"):
    if not member:
        await ctx.send("Usage: `!kick @member [reason]`")
        return
    if is_owner_user(member):
        await ctx.send("❌ You cannot kick the owner.")
        return
    try:
        await member.kick(reason=reason)
        embed = discord.Embed(
            title="👢 Member Kicked",
            description=f"{member.mention} has been kicked.",
            color=discord.Color.red()
        )
        embed.add_field(name="Reason", value=reason)
        embed.set_footer(text=f"Action by {ctx.author.display_name}")
        await ctx.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ I don't have permission to kick that member.")


@bot.command(name="warnings")
@is_owner()
async def check_warnings(ctx: commands.Context, member: discord.Member = None):
    if not member:
        await ctx.send("Usage: `!warnings @member`")
        return
    count = member_warnings.get(member.id, 0)
    embed = discord.Embed(
        title="📋 Warning Count",
        description=f"{member.mention} has **{count}** warning(s).",
        color=discord.Color.yellow()
    )
    await ctx.send(embed=embed)


@bot.command(name="clearwarnings")
@is_owner()
async def clear_warnings(ctx: commands.Context, member: discord.Member = None):
    if not member:
        await ctx.send("Usage: `!clearwarnings @member`")
        return
    member_warnings[member.id] = 0
    embed = discord.Embed(
        title="✅ Warnings Cleared",
        description=f"All warnings for {member.mention} have been cleared.",
        color=discord.Color.green()
    )
    await ctx.send(embed=embed)


@bot.command(name="bothelp")
async def bot_help(ctx: commands.Context):
    if ctx.channel.name not in ALLOWED_CHANNELS and not is_owner_user(ctx.author):
        return
    embed = discord.Embed(
        title="🤖 Bot Commands",
        description=f"Commands work in `#bot-chat` and `#👑emperor-ship-❤️‍🔥` only.",
        color=discord.Color.blurple()
    )
    embed.add_field(
        name="🌐 For Everyone",
        value=(
            "`!ask <question>` — Ask AI anything\n"
            "`!roast [@member]` — Roast someone (fun)\n"
            "`!joke` — Get a random joke\n"
            "`!advice [topic]` — Get life advice\n"
            "`!userinfo [@member]` — View member info\n"
            "`!serverinfo` — View server info\n"
            "`!poll <question>` — Start a poll\n"
            "`!bothelp` — Show this message"
        ),
        inline=False
    )
    embed.add_field(
        name="👑 Owner Only",
        value=(
            "`!timeout @member <min> [reason]` — Timeout\n"
            "`!untimeout @member` — Remove timeout\n"
            "`!ban @member [reason]` — Ban\n"
            "`!unban <user_id>` — Unban\n"
            "`!kick @member [reason]` — Kick\n"
            "`!warnings @member` — Check warnings\n"
            "`!clearwarnings @member` — Clear warnings\n"
            "`!purge <amount>` — Delete messages\n"
            "`!say <text>` — Bot sends a message\n"
            "`!announce <text>` — Make announcement"
        ),
        inline=False
    )
    embed.add_field(
        name="🛡️ Auto-Moderation",
        value=(
            "• Deletes links + warns user\n"
            "• Warns for abusive language\n"
            "• Auto-timeout after **3 warnings** (10 min)"
        ),
        inline=False
    )
    embed.set_footer(text="Stay respectful and have fun! 😊")
    await ctx.send(embed=embed)


@bot.event
async def on_command_error(ctx: commands.Context, error):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.CheckFailure):
        return
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"❌ Missing argument. Use `!bothelp` to see command usage.")
        return
    raise error


bot.run(DISCORD_BOT_TOKEN)
