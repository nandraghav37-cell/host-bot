import discord
from discord.ext import commands, tasks
from discord import app_commands
import os
import re
import random
import json
from datetime import datetime, timedelta

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True

bot = commands.Bot(command_prefix='/', intents=intents, help_command=None)

CHAT_CHANNEL_NAMES = ['🤖ai-chat', '👑emperor-ship-❤️‍🔥']
STAFF_ROLES = ['owner', 'co-owner', 'helper', 'trail helper', 'Trail Helper', 'trial helper', 'trailhelper', 'trialhelper', 'admin', 'moderator', 'staff', 'mod']
OWNER_ROLES = ['owner']
TICKET_WAIT_MINUTES = 4

pending_tickets = {}
bot_replied_tickets = {}

EXTRA_CHANNELS_FILE = 'bot/extra_chat_channels.json'

def load_extra_channels():
    try:
        with open(EXTRA_CHANNELS_FILE, 'r') as f:
            return set(json.load(f))
    except Exception:
        return set()

def save_extra_channels():
    try:
        with open(EXTRA_CHANNELS_FILE, 'w') as f:
            json.dump(list(extra_chat_channel_ids), f)
    except Exception as e:
        print(f'❌ Could not save extra channels: {e}')

extra_chat_channel_ids: set = load_extra_channels()

BAD_WORDS = [
    'fuck', 'shit', 'bitch', 'cunt', 'dick', 'pussy', 'nigga', 'nigger',
    'bastard', 'whore', 'slut', 'faggot', 'retard'
]

LINK_PATTERN = re.compile(r'(https?://|discord\.gg/|www\.)[^\s]+', re.IGNORECASE)

CHAT_REPLIES = {
    'greet': [
        "Heyy bestie! 👋 How you doing?",
        "Yooo what's good! 😄",
        "Heyyy welcome welcome! 👋✨",
        "Hi there! Hope your day's been an absolute vibe 😊",
        "Yooo! What's poppin 😎",
        "Hewwo! 👋 Glad you're here!",
    ],
    'how_are_you': [
        "Lowkey doing great bestie, tysm for asking! 😊 How about you?",
        "All good on my end no cap! 😄 What's up?",
        "Honestly thriving rn 😎 you?",
        "I'm good I'm good! Hope you're vibing too 💙",
    ],
    'good': [
        "Omg that's so good to hear bestie! 🙌",
        "Slay! Love that for you 💅",
        "Yesss that's the vibe fr 💪",
        "Let's gooo! Happy for you 🎉",
        "W response no cap 😊",
    ],
    'bad': [
        "Aw bestie I'm sorry 😔 hope things get better real soon 💙",
        "Noo that's not it 😭 sending good vibes your way 💙",
        "Hang tight bestie, it gets better fr 💪",
        "Lowkey rough but you got this 💙 I believe in you!",
    ],
    'bored': [
        "Broo same ngl 😭 chat with me then!",
        "Lmao same bestie, let's vibe 😄",
        "Bored szn has arrived 😂 I gotchu tho, let's talk!",
    ],
    'thanks': [
        "Ofc bestie no problem at all! 😊",
        "Anytime fr! 🙌",
        "Always here for you! 💙",
        "No worries at all! 😄",
    ],
    'bye': [
        "Byeee take care bestie! 👋💙",
        "Later! Hope you have an amazing day 😊",
        "Cya! Come back soon 👋",
        "Byee! Stay safe out there 💙",
    ],
    'default': [
        "Fr fr no cap 😂",
        "Lowkey that's kinda valid tho 👀",
        "Bestie said what they said 💅",
        "Ngl that's sending me 😂",
        "Sheesh 👀 okay I see you",
        "No way bro really said that 💀",
        "That's actually so real 🗣️",
        "W take honestly 🙌",
        "Based and I respect it 😎",
        "Facts 💯 periodt",
        "It's giving everything fr 😂",
        "The audacity 💀 (jk lol)",
        "Understood bestie 😊",
        "Slay honestly 💅",
    ]
}

SERVICE_PRICES = """🟥 **NOVA SERVICE PRICES**

⚔️ **RAIDS**
1–5 ➤ Buddha / Portal (8M+)
6–9 ➤ T-Rex / Venom / Dough
10–14 ➤ Gas (40M+)
15–17 ➤ Lightning (80M)
18–20 ➤ Yeti / Tiger
20+ ➤ Ask in Ticket

🔥 **ADVANCED RAIDS (Phoenix Included)**
1–2 ➤ Buddha / Portal (10M+)
3–5 ➤ T-Rex + Buddha / Portal
6–8 ➤ Dough + T-Rex / Venom (20M+)
9–11 ➤ Gas (50M+)

⚡ **TRIALS**
**No Training:**
1 ➤ 10M+
2 ➤ Dough (20M+)
3 ➤ Gas (50M+)
4 ➤ Lightning (80M+)

**With Training:**
1 ➤ +20M
2 ➤ Gas (30M+)
3 ➤ Lightning / Gas + Buddha / Portal
4 ➤ Tiger+

🌊 **SEA EVENTS**
Leviathan ➤ Yeti + Buddha / Portal / Tiger
Mirage ➤ Lightning / 80M+ / Gamepass
Kitsune Shrine ➤ Dough + Buddha
Prehistoric ➤ Gas / Dough + Venom / T-Rex

💰 **MONEY GRIND**
No 2x ➤ 5M
With 2x ➤ 7M

📈 **MASTERY**
No 2x ➤ 0–400+
With 2x ➤ 0–500+

👑 **BOSSES**
Rip Indra ➤ Lightning (90M+)
Darkbeard ➤ Yeti / Gas + Dough
Cake Prince ➤ Dough + Buddha
Dough King ➤ 60M+ / Gas
Tyrant ➤ Dough + T-Rex / 50M+

📌 **NOTE:**
➤ Prices negotiable
➤ Open ticket for help 🎟️"""


# ─── Helpers ──────────────────────────────────────────────────────────────────

def is_ticket_channel(channel):
    name = channel.name.lower()
    return (
        'ticket' in name or
        'support' in name or
        '🎟' in channel.name or
        '🎫' in channel.name
    )


def is_chat_channel(channel):
    if channel.id in extra_chat_channel_ids:
        return True
    name = channel.name.lower()
    return (
        'ai-chat' in name or
        'ai chat' in name or
        'aichat' in name or
        'bot-chat' in name or
        'bot chat' in name or
        'botchat' in name or
        'emperor' in name or
        'emperorship' in name or
        'emperor-ship' in name
    )


def has_staff_role(member):
    if member.bot:
        return False
    return any(s in [r.name.lower() for r in member.roles] for s in STAFF_ROLES)


def is_owner(member):
    if member.bot:
        return False
    role_names = [r.name.lower() for r in member.roles]
    return any(o in role_names for o in OWNER_ROLES) or member.guild_permissions.administrator


def contains_bad_word(text):
    lower = text.lower()
    return any(w in lower for w in BAD_WORDS)


def contains_link(text):
    return bool(LINK_PATTERN.search(text))


KNOWLEDGE_REPLIES = [
    "Bestie that's kinda above my pay grade ngl 😅 I'm just a Nova bot, not Google lol — maybe try searching it up! 🔍",
    "Omg I actually don't know that one fr 😭 I wish I could help bestie! Try googling it real quick 🙏",
    "Ngl I'm a vibe bot not a teacher 💀 I don't have that info but Google got u bestie 🔍",
    "Hmm I genuinely don't know that one no cap 😬 I'd hate to give u wrong info so google might be ur bestie here 📚",
    "That's a bit outside my brain ngl 😂 I only really know Nova stuff! Google has ur back tho 🙌",
]

def get_chat_reply(content_lower):
    if any(w in content_lower for w in ['hi', 'hey', 'hello', 'sup', 'yo', 'heyy', 'wassup']):
        return random.choice(CHAT_REPLIES['greet'])
    if any(w in content_lower for w in ['how are you', 'how r u', 'how ru', 'hru', 'u good', 'you good']):
        return random.choice(CHAT_REPLIES['how_are_you'])
    if any(w in content_lower for w in ['im good', "i'm good", 'im fine', 'im great', 'doing good', 'doing well', 'all good']):
        return random.choice(CHAT_REPLIES['good'])
    if any(w in content_lower for w in ['im bad', "i'm bad", 'im sad', 'not good', 'terrible', 'awful']):
        return random.choice(CHAT_REPLIES['bad'])
    if 'bored' in content_lower:
        return random.choice(CHAT_REPLIES['bored'])
    if any(w in content_lower for w in ['thanks', 'thank you', 'thx', 'ty', 'thnx']):
        return random.choice(CHAT_REPLIES['thanks'])
    if any(w in content_lower for w in ['bye', 'cya', 'see ya', 'later', 'gtg', 'gotta go']):
        return random.choice(CHAT_REPLIES['bye'])
    if any(w in content_lower for w in ['how to make bot', 'how to create bot', 'how make bot']):
        return "Making a bot takes some coding knowledge bestie 💻 Not really my area but there are great tutorials online! 🙌"
    if 'can you timeout' in content_lower or 'timeout someone' in content_lower:
        return "Only staff can do timeouts here bestie, I'm just here to chat 😅"
    if any(w in content_lower for w in ['what is', 'what are', 'who is', 'who are', 'how does', 'why is', 'why does', 'when is', 'when did', 'where is', 'explain', 'tell me about']):
        return random.choice(KNOWLEDGE_REPLIES)
    if content_lower.endswith('?'):
        return random.choice(KNOWLEDGE_REPLIES)
    return random.choice(CHAT_REPLIES['default'])


async def safe_delete(message):
    try:
        await message.delete()
    except Exception:
        pass


async def safe_timeout(member, duration, reason):
    try:
        await member.timeout(duration, reason=reason)
        return True
    except discord.Forbidden:
        return False


# ─── Events ───────────────────────────────────────────────────────────────────

@bot.event
async def on_ready():
    print(f'✅ Bot online as {bot.user} (ID: {bot.user.id})')
    print(f'✅ Connected to {len(bot.guilds)} server(s)')
    for guild in bot.guilds:
        print(f'📋 Server: {guild.name}')
        for ch in guild.text_channels:
            tag = ''
            if is_ticket_channel(ch):
                tag = ' [TICKET]'
            elif is_chat_channel(ch):
                tag = ' [CHAT]'
            print(f'   #{ch.name}{tag}')
    await bot.change_presence(
        status=discord.Status.online,
        activity=discord.Game(name="Nova Service 👑")
    )
    try:
        synced = await bot.tree.sync()
        print(f'✅ Synced {len(synced)} slash command(s)')
    except Exception as e:
        print(f'❌ Sync failed: {e}')
    if not check_pending_tickets.is_running():
        check_pending_tickets.start()


@bot.event
async def on_disconnect():
    print('⚠️ Disconnected — reconnecting...')


@bot.event
async def on_resumed():
    print('✅ Reconnected!')


@bot.event
async def on_message(message):
    if message.author == bot.user or message.author.bot:
        return

    channel = message.channel
    content = message.content
    content_lower = content.lower()
    member = message.author

    # ── @everyone / @here ─────────────────────────────────────────────────────
    if message.mention_everyone and not is_owner(member):
        await safe_delete(message)
        await channel.send(
            f"⛔ Hey {member.mention}, pinging **@everyone** or **@here** isn't allowed bestie. "
            f"Please keep that in mind, ty! 💙"
        )
        return

    # ── Bad words ─────────────────────────────────────────────────────────────
    if contains_bad_word(content):
        await safe_delete(message)
        timed_out = await safe_timeout(member, timedelta(minutes=1), reason='Bad language')
        if timed_out:
            await channel.send(
                f"⚠️ Hey {member.mention}, please keep the language respectful bestie! 🙏 "
                f"Your message was removed and you've been given a **1 minute timeout**. "
                f"We appreciate you keeping things chill 💙"
            )
        else:
            await channel.send(
                f"⚠️ Hey {member.mention}, please keep it respectful! 🙏 "
                f"Your message was removed. Let's keep the vibes positive 💙"
            )
        return

    # ── Links (non-staff) ─────────────────────────────────────────────────────
    if contains_link(content) and not has_staff_role(member):
        await safe_delete(message)
        await channel.send(
            f"🔗 Heyyy {member.mention}, links aren't allowed here bestie! "
            f"Please keep that in mind, tysm 💙"
        )
        return

    # ── Tickets ───────────────────────────────────────────────────────────────
    if is_ticket_channel(channel):
        if has_staff_role(member):
            pending_tickets.pop(channel.id, None)
            bot_replied_tickets.pop(channel.id, None)
        else:
            if channel.id not in pending_tickets and channel.id not in bot_replied_tickets:
                pending_tickets[channel.id] = datetime.utcnow()
                await channel.send(
                    f"Heyy {member.mention}! 👋 Welcome to your ticket bestie, we gotchu!\n\n"
                    f"Could you please let us know:\n"
                    f"**1.** What service do you need help with? 🎯\n"
                    f"**2.** What is your payment method? 💳\n\n"
                    f"⏳ Hang tight — a staff member will be with you shortly! No cap 💙"
                )
        return

    # ── Chat channels — natural conversation ──────────────────────────────────
    if is_chat_channel(channel):
        reply = get_chat_reply(content_lower)
        await channel.send(f"{member.mention} {reply}")


# ─── Ticket auto-reply ────────────────────────────────────────────────────────

@tasks.loop(seconds=30)
async def check_pending_tickets():
    now = datetime.utcnow()
    to_remove = []
    for channel_id, created_at in list(pending_tickets.items()):
        if now - created_at >= timedelta(minutes=TICKET_WAIT_MINUTES):
            channel = bot.get_channel(channel_id)
            if channel:
                try:
                    await channel.send(
                        "Heyy bestie! 💙 Our staff is on their way, tysm for your patience!\n"
                        "While you wait, here are our service prices so you can pick what you need:\n\n"
                        + SERVICE_PRICES
                    )
                    bot_replied_tickets[channel_id] = True
                except Exception as e:
                    print(f'❌ Ticket reply error {channel_id}: {e}')
            to_remove.append(channel_id)
    for cid in to_remove:
        pending_tickets.pop(cid, None)


@check_pending_tickets.before_loop
async def before_check():
    await bot.wait_until_ready()


# ─── Owner guard ──────────────────────────────────────────────────────────────

async def owner_only(interaction: discord.Interaction) -> bool:
    if is_owner(interaction.user):
        return True
    await interaction.response.send_message("❌ Only the **Owner** can use this.", ephemeral=True)
    return False


# ─── Slash Commands ───────────────────────────────────────────────────────────

@bot.tree.command(name='prices', description='Show Nova service prices')
async def slash_prices(interaction: discord.Interaction):
    await interaction.response.send_message(SERVICE_PRICES)


@bot.tree.command(name='ticket', description='How to open a support ticket')
async def slash_ticket(interaction: discord.Interaction):
    await interaction.response.send_message("🎟️ Open a ticket and our staff will assist you shortly!")


@bot.tree.command(name='ping', description='Check bot latency')
async def slash_ping(interaction: discord.Interaction):
    await interaction.response.send_message(f'🏓 `{round(bot.latency * 1000)}ms`')


@bot.tree.command(name='help', description='Show all commands')
async def slash_help(interaction: discord.Interaction):
    embed = discord.Embed(title="📖 Nova Bot Commands", color=discord.Color.red())
    embed.add_field(name='/prices', value='Show service prices', inline=False)
    embed.add_field(name='/ticket', value='Ticket info', inline=False)
    embed.add_field(name='/ping', value='Bot latency', inline=False)
    embed.add_field(name='/addchannel #channel', value='*(Owner)* Make bot chat in a channel', inline=False)
    embed.add_field(name='/removechannel #channel', value='*(Owner)* Stop bot from chatting in a channel', inline=False)
    embed.add_field(name='/kick @user [reason]', value='*(Owner)* Kick a member', inline=False)
    embed.add_field(name='/timeout @user [minutes] [reason]', value='*(Owner)* Timeout a member', inline=False)
    embed.add_field(name='/untimeout @user', value='*(Owner)* Remove timeout', inline=False)
    embed.add_field(name='/warn @user [reason]', value='*(Owner)* Warn a member', inline=False)
    embed.add_field(name='/purge [amount]', value='*(Owner)* Delete messages', inline=False)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name='addchannel', description='[Owner] Make bot chat in a channel')
@app_commands.describe(channel='Channel to add')
async def slash_addchannel(interaction: discord.Interaction, channel: discord.TextChannel):
    if not await owner_only(interaction):
        return
    extra_chat_channel_ids.add(channel.id)
    save_extra_channels()
    await interaction.response.send_message(
        f'✅ Done bestie! The bot will now chat in {channel.mention} no cap 💙',
        ephemeral=True
    )


@bot.tree.command(name='removechannel', description='[Owner] Stop bot from chatting in a channel')
@app_commands.describe(channel='Channel to remove')
async def slash_removechannel(interaction: discord.Interaction, channel: discord.TextChannel):
    if not await owner_only(interaction):
        return
    extra_chat_channel_ids.discard(channel.id)
    save_extra_channels()
    await interaction.response.send_message(
        f'✅ Got it! The bot will no longer chat in {channel.mention} 💙',
        ephemeral=True
    )


@bot.tree.command(name='kick', description='[Owner] Kick a member')
@app_commands.describe(member='Member to kick', reason='Reason')
async def slash_kick(interaction: discord.Interaction, member: discord.Member, reason: str = 'No reason provided'):
    if not await owner_only(interaction):
        return
    try:
        await member.kick(reason=reason)
        await interaction.response.send_message(f'👢 **{member}** kicked. Reason: {reason}')
    except discord.Forbidden:
        await interaction.response.send_message('❌ Missing permission to kick.', ephemeral=True)


@bot.tree.command(name='timeout', description='[Owner] Timeout a member')
@app_commands.describe(member='Member to timeout', minutes='Minutes (default 5)', reason='Reason')
async def slash_timeout(interaction: discord.Interaction, member: discord.Member, minutes: int = 5, reason: str = 'No reason provided'):
    if not await owner_only(interaction):
        return
    try:
        await member.timeout(timedelta(minutes=minutes), reason=reason)
        await interaction.response.send_message(f'⏱️ **{member}** timed out for **{minutes}m**. Reason: {reason}')
    except discord.Forbidden:
        await interaction.response.send_message('❌ Missing permission to timeout.', ephemeral=True)


@bot.tree.command(name='untimeout', description='[Owner] Remove timeout from a member')
@app_commands.describe(member='Member to un-timeout')
async def slash_untimeout(interaction: discord.Interaction, member: discord.Member):
    if not await owner_only(interaction):
        return
    try:
        await member.timeout(None)
        await interaction.response.send_message(f'✅ Timeout removed from **{member}**.')
    except discord.Forbidden:
        await interaction.response.send_message('❌ Missing permission.', ephemeral=True)


@bot.tree.command(name='warn', description='[Owner] Warn a member')
@app_commands.describe(member='Member to warn', reason='Reason')
async def slash_warn(interaction: discord.Interaction, member: discord.Member, reason: str = 'No reason provided'):
    if not await owner_only(interaction):
        return
    try:
        await member.send(f'⚠️ You were warned in **{interaction.guild.name}**. Reason: {reason}')
    except Exception:
        pass
    await interaction.response.send_message(f'⚠️ **{member}** warned. Reason: {reason}')


@bot.tree.command(name='purge', description='[Owner] Delete multiple messages')
@app_commands.describe(amount='How many messages to delete (max 100)')
async def slash_purge(interaction: discord.Interaction, amount: int = 10):
    if not await owner_only(interaction):
        return
    if not 1 <= amount <= 100:
        await interaction.response.send_message('❌ Enter a number between 1–100.', ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    deleted = await interaction.channel.purge(limit=amount)
    await interaction.followup.send(f'🗑️ Deleted **{len(deleted)}** message(s).', ephemeral=True)


# ─── Run ──────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    token = os.environ.get('DISCORD_BOT_TOKEN')
    if not token:
        print('❌ DISCORD_BOT_TOKEN not set!')
    else:
        print('🚀 Starting Nova Bot...')
        bot.run(token, reconnect=True)
